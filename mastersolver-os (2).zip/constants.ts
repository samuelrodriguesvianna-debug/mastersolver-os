
import { Floor } from './types';

// An array containing the definitions for all 17 floors of the MasterSolver-OS methodology.
// Each object defines the content and prompts for a specific step in the process.
export const FLOORS: Floor[] = [
  {
    id: 1,
    title: "Andar 1: Dor Real",
    subtitle: "Ativação da dor verdadeira.",
    description: "Toda grande solução começa com um problema bem definido. Descreva a dor, o atrito ou o desafio que você está enfrentando da forma mais crua e honesta possível. Sem uma dor clara, não há avanço.",
    documentation: "O objetivo deste andar é ir além dos sintomas superficiais e identificar a dor fundamental que impulsiona a necessidade de mudança. Uma definição clara da dor é o alicerce de toda a análise estratégica. Evite jargões corporativos e foque no impacto real e tangível do problema.",
    prompt: "Qual é a dor ou problema fundamental que motiva esta análise?",
    aiPrompt: "Você é um especialista em diagnóstico de negócios. Refine a seguinte descrição de um problema para focar na 'dor real' subjacente, eliminando sintomas superficiais e jargões. A resposta deve ser concisa e impactante. Descrição original:"
  },
  {
    id: 2,
    title: "Andar 2: Contexto, Causa e Limites",
    subtitle: "Separação entre contexto, causas influentes e restrições reais.",
    description: "Problemas não existem no vácuo. Descreva o ambiente, os fatores que contribuem para o problema e as restrições (orçamento, tempo, regulamentação) que você não pode mudar. Isso define o campo de jogo.",
    documentation: "Neste andar, você mapeia o 'terreno'. O contexto descreve o cenário (mercado, concorrência). As causas são os fatores que você acredita estarem contribuindo para a 'dor real'. Os limites são as 'regras do jogo' que não podem ser alteradas. Uma análise clara aqui evita que se busquem soluções inviáveis.",
    prompt: "Qual é o contexto, as causas principais e as restrições inalteráveis deste problema?",
    aiPrompt: "Você é um analista estratégico. Organize o texto a seguir em três seções claras: 'Contexto', 'Causas Prováveis' e 'Restrições Reais'. Sintetize as informações para fornecer um panorama claro do ambiente do problema. Texto original:"
  },
   {
    id: 3,
    title: "Andar 3: Problema Real vs. Sintoma",
    subtitle: "Eliminação de falsas causas e redução do escopo decisório.",
    description: "Muitas vezes, o que percebemos como 'o problema' é apenas um sintoma. Diferencie os sintomas (ex: queda nas vendas) do problema real (ex: produto desalinhado com o mercado). Focar no problema raiz evita desperdício de esforço.",
    documentation: "Este é um ponto crítico de diagnóstico. A 'queda nas vendas' é um sintoma. O problema real pode ser a qualidade do produto, o preço, a estratégia de marketing, etc. Focar em resolver o sintoma (ex: oferecer descontos) sem tratar a causa raiz raramente leva a uma solução sustentável.",
    prompt: "Qual é o verdadeiro problema a ser resolvido, distinguindo-o de seus sintomas?",
    aiPrompt: "Você é um mestre em resolução de problemas. Analise a seguinte declaração e reformule-a para distinguir claramente o 'Problema Central' de seus 'Sintomas Visíveis'. A nova formulação deve focar na causa raiz. Declaração original:",
    benchmarkPrompt: "Analise a definição do problema a seguir. Compare-a com as melhores práticas de definição de problemas (ex: 5 Porquês, Diagrama de Ishikawa). Aponte se a definição atual parece focar na causa raiz ou ainda está no nível dos sintomas, e sugira caminhos para aprofundar a análise."
  },
  {
    id: 4,
    title: "Andar 4: Objetivo Correto & Critério de Sucesso",
    subtitle: "Definição de um objetivo que elimina o problema + métrica observável.",
    description: "O que significa 'resolver' este problema? Defina um objetivo claro, específico e mensurável. Como você saberá que teve sucesso? Estabeleça um critério de sucesso (uma métrica) que não deixe espaço para ambiguidade.",
    documentation: "Um bom objetivo é SMART: Específico, Mensurável, Atingível, Relevante e com Prazo definido. O critério de sucesso é a métrica que comprova que o objetivo foi alcançado. Ex: Objetivo - 'Aumentar a retenção de clientes em 15% até o final do Q3'. Critério de Sucesso: 'Taxa de retenção medida pelo nosso CRM'.",
    prompt: "Qual é o objetivo principal e qual métrica específica indicará o sucesso?",
    aiPrompt: "Transforme a seguinte meta em um objetivo SMART (Específico, Mensurável, Atingível, Relevante, Temporal). Defina um 'Objetivo Principal' claro e um 'Critério de Sucesso' quantificável. Meta original:",
    benchmarkPrompt: "Avalie o objetivo e o critério de sucesso a seguir. Eles seguem a metodologia SMART? A métrica de sucesso é diretamente observável e ligada ao objetivo? Ofereça sugestões para torná-los mais robustos e menos ambíguos."
  },
  {
    id: 5,
    title: "Andar 5: Recursos, Restrições & Alavancas",
    subtitle: "Viabilidade real e poder decisório concreto.",
    description: "Mapeie os recursos disponíveis (equipe, orçamento, tecnologia), as restrições (limites) e as alavancas (pequenos esforços com grande impacto). Isso fundamenta a decisão na realidade operacional.",
    documentation: "Este andar é um 'choque de realidade'. Recursos são o que você tem para trabalhar. Restrições são os limites que você enfrenta (diferente dos limites do Andar 2, estas podem ser negociáveis). Alavancas são os pontos onde uma pequena força pode gerar um grande resultado, como otimizar um processo chave.",
    prompt: "Liste os recursos, restrições e possíveis alavancas para alcançar o objetivo.",
    aiPrompt: "Analise a lista de ativos e limitações e identifique as 'Alavancas Estratégicas' mais promissoras - ações que podem gerar o máximo impacto com o mínimo de recursos. Liste-as em ordem de potencial. Ativos e limitações:"
  },
  {
    id: 6,
    title: "Andar 6: Priorização & Escolha Consciente",
    subtitle: "Escolhas excludentes e custo de oportunidade explícito.",
    description: "Você não pode fazer tudo. Quais são as opções de ação? Qual delas oferece o melhor retorno sobre o investimento de recursos? Escolher um caminho significa não seguir outros. Este é o momento da decisão estratégica.",
    documentation: "A essência da estratégia é a escolha. Neste andar, você lista as alternativas viáveis para atingir seu objetivo. A priorização (usando frameworks como a Matriz de Impacto vs. Esforço) ajuda a tomar uma decisão baseada em lógica, não apenas em intuição. Reconhecer o 'custo de oportunidade' - o que você está deixando de fazer - é um sinal de maturidade decisória.",
    prompt: "Quais são as principais linhas de ação possíveis? Qual será priorizada e por quê?",
    aiPrompt: "Com base nas opções de ação fornecidas, crie uma matriz de priorização (Impacto vs. Esforço). Avalie cada opção em 'impacto' e 'esforço' numa escala de 1 a 10. Sugira a opção mais estratégica e justifique. Opções:"
  },
  {
    id: 7,
    title: "Andar 7: Hipóteses de Ação",
    subtitle: "Transformação da decisão em tese testável.",
    description: "Sua decisão é uma aposta baseada em premissas. Transforme sua linha de ação escolhida em uma hipótese clara: 'Se fizermos A, esperamos que B aconteça, o que será medido por C'. Isso torna a estratégia testável.",
    documentation: "Transformar uma decisão em uma hipótese força a clareza de pensamento. Ela conecta a AÇÃO (o que vamos fazer), o RESULTADO ESPERADO (o que acreditamos que vai acontecer) e a MÉTRICA (como vamos medir). Isso cria um ciclo de aprendizado: se a métrica não mudar, ou a ação estava errada, ou a premissa estava errada.",
    prompt: "Formule a sua decisão como uma hipótese testável (Se... então...)",
    aiPrompt: "Converta a seguinte decisão em uma hipótese de ação clara e formal. Use o formato: 'Acreditamos que [AÇÃO] para [PÚBLICO] resultará em [RESULTADO ESPERADO], e saberemos que estamos certos quando [MÉTRICA] mudar de X para Y'. Decisão:",
    semiAutomaticPrompt: "Com base na seguinte decisão priorizada do Andar 6, formule uma hipótese de ação clara no formato 'Se... então...'. Decisão:"
  },
  {
    id: 8,
    title: "Andar 8: Riscos & Falhas Previsíveis",
    subtitle: "Antecipação de quebra, impacto e dano aceitável.",
    description: "O que pode dar errado? Liste os riscos potenciais da sua hipótese. Para cada risco, estime a probabilidade e o impacto. O que você fará para mitigar os riscos mais críticos? Planejar para a falha aumenta a chance de sucesso.",
    documentation: "Gerenciamento de risco proativo é crucial. Em vez de reagir a problemas, você os antecipa. Para cada risco identificado, pense em um plano de mitigação (como reduzir a chance de acontecer) ou um plano de contingência (o que fazer se acontecer). Focar nos riscos de alto impacto e alta probabilidade é o mais eficiente.",
    prompt: "Quais são os principais riscos e como eles serão mitigados?",
    aiPrompt: "Você é um gerente de riscos experiente. Para a ação proposta, identifique 3 a 5 'Riscos Críticos' e sugira uma 'Ação de Mitigação' para cada um. Foque em riscos que poderiam comprometer todo o plano. Plano de Ação:",
    semiAutomaticPrompt: "Com base na seguinte hipótese de ação do Andar 7, identifique de 3 a 5 riscos críticos e sugira uma ação de mitigação para cada. Hipótese:"
  },
  {
    id: 9,
    title: "Andar 9: Execução Integrada",
    subtitle: "Movimento mínimo coordenado entre pessoas e sistemas.",
    description: "Defina o primeiro passo. Qual é a menor ação coordenada que pode ser tomada para testar sua hipótese? Quem precisa fazer o quê e quando? Clareza na execução é fundamental.",
    documentation: "A melhor estratégia falha sem uma boa execução. Este andar traduz a hipótese em um plano de ação concreto e mínimo (MVP - Mínimo Produto Viável ou Mínimo Teste Viável). A clareza sobre 'quem faz o quê até quando' é essencial para evitar descoordenação e paralisia.",
    prompt: "Qual é o plano de execução mínimo e quem são os responsáveis?",
    aiPrompt: "Transforme o seguinte plano em um 'Plano de Ação Mínimo Viável' (MVP). Defina as 3 primeiras etapas concretas, atribuindo um 'Responsável' e um 'Prazo' para cada uma. Plano geral:"
  },
  {
    id: 10,
    title: "Andar 10: Sinais & Feedback",
    subtitle: "Observação da realidade antes de julgamento.",
    description: "Como você vai monitorar o progresso? Defina os indicadores (leading e lagging) que você irá acompanhar. Crie um sistema para coletar dados e feedback de forma consistente.",
    documentation: "'Leading indicators' são métricas preditivas que mostram o progresso inicial (ex: número de leads gerados). 'Lagging indicators' são métricas de resultado que confirmam o sucesso (ex: receita gerada). Monitorar ambos fornece uma visão completa do desempenho da sua iniciativa.",
    prompt: "Quais sinais e métricas serão monitorados para avaliar o progresso?",
    aiPrompt: "Para o objetivo definido, sugira 2 'Leading Indicators' (sinais precoces de progresso) e 1 'Lagging Indicator' (confirmação do resultado final). Explique por que cada um é importante. Objetivo:"
  },
  {
    id: 11,
    title: "Andar 11: Aprendizado Estruturado",
    subtitle: "Classificação objetiva do erro.",
    description: "Após a execução inicial, analise os resultados. O que aconteceu? Por que aconteceu? O erro foi de execução ou de estratégia (a hipótese estava errada)? Classifique o resultado de forma objetiva.",
    documentation: "Este é o andar do 'post-mortem'. A análise deve ser objetiva e focada no aprendizado, não na culpa. A distinção entre erro de execução (o plano era bom, mas falhamos em executá-lo) e erro de estratégia (executamos bem um plano ruim) é vital para a melhoria contínua.",
    prompt: "Analise os resultados: o que aprendemos com a execução?",
    aiPrompt: "Com base nos resultados, escreva uma análise 'post-mortem' concisa. Responda: 1. O que esperávamos que acontecesse? 2. O que realmente aconteceu? 3. Por que houve uma diferença? 4. O que faremos de diferente da próxima vez? Resultados:"
  },
  {
    id: 12,
    title: "Andar 12: Ajuste ou Aborto",
    subtitle: "Decisão madura de continuidade ou encerramento.",
    description: "Com base no aprendizado, decida: devemos continuar e ajustar o plano, ou devemos abortar a iniciativa? Uma decisão de parar não é um fracasso, mas um ato de disciplina estratégica para realocar recursos de forma mais eficaz.",
    documentation: "Saber quando 'pivotar' (ajustar) ou 'parar' uma iniciativa é uma habilidade de liderança de alto nível. A decisão deve ser baseada nos aprendizados do Andar 11 e no objetivo estratégico original. Manter uma iniciativa falha por apego emocional é um erro comum que este andar visa evitar.",
    prompt: "Com base no aprendizado, a decisão é ajustar o plano ou abortar a iniciativa? Justifique.",
    aiPrompt: "Você é um conselheiro executivo. Com base na análise, redija uma recomendação clara: 'PIVOTAR', 'PERSEVERAR' ou 'PARAR'. Justifique sua escolha com base nos dados e no objetivo estratégico. Análise:"
  },
  {
    id: 13,
    title: "Andar 13: Decisão de Alto Risco",
    subtitle: "Autoridade total do decisor.",
    description: "Este andar é para decisões de grande impacto onde os dados são insuficientes. A responsabilidade é total do decisor. O sistema silencia, apresentando os fatos, e a decisão final é baseada em julgamento e experiência.",
    documentation: "Nem todas as decisões podem ser 100% baseadas em dados. Para as decisões mais críticas e incertas, o sistema organiza toda a informação disponível para dar clareza ao líder, mas a decisão final é um ato de julgamento. Este andar formaliza esse momento de responsabilidade máxima.",
    prompt: "Esta é uma decisão de alto risco. Declare sua decisão final e o racional principal.",
    aiPrompt: "Sintetize todos os dados e análises anteriores em um 'Sumário Executivo para Decisão de Alto Risco'. Apresente os prós e contras de forma neutra, deixando a decisão final para o líder. Dados:"
  },
  {
    id: 14,
    title: "Andar 14: Escala Controlada",
    subtitle: "Ampliação sem amplificar erro.",
    description: "Se a iniciativa foi um sucesso, como podemos ampliá-la de forma segura? Defina um plano de escalonamento que preveja novos desafios (comunicação, tecnologia, logística) e não amplifique pequenos erros que eram irrelevantes na fase de teste.",
    documentation: "Escalar uma solução de sucesso não é simplesmente 'fazer mais do mesmo'. Novos desafios surgem com a escala. Este andar planeja um crescimento gradual e controlado, com fases e portões de qualidade, para garantir que o sucesso inicial não se transforme em um fracasso em larga escala.",
    prompt: "Como a solução será escalada de forma controlada?",
    aiPrompt: "Desenvolva um 'Plano de Escala Gradual' em 3 fases. Para cada fase, defina: 'Objetivo', 'Recursos Necessários' e 'Critérios de Sucesso' para avançar para a próxima fase. Solução validada:"
  },
  {
    id: 15,
    title: "Andar 15: Institucionalização",
    subtitle: "Transformação do acerto em padrão organizacional.",
    description: "O sucesso não pode depender de heróis. Como transformar o aprendizado e o novo processo em um padrão para a organização? Crie documentação, treinamento e sistemas que incorporem a nova forma de trabalhar.",
    documentation: "Este andar transforma um projeto de sucesso em 'a nova forma como fazemos as coisas aqui'. Isso envolve criar Procedimentos Operacionais Padrão (POPs), treinar equipes e integrar o novo processo às ferramentas existentes para garantir que o ganho de performance seja sustentável e não dependa de uma única pessoa ou equipe.",
    prompt: "Como este sucesso será transformado em um processo padrão na organização?",
    aiPrompt: "Esboce um 'Plano de Institucionalização'. Inclua seções para: 1. Documentação (criação de um playbook), 2. Treinamento (quem precisa ser treinado), e 3. Sistemas (ferramentas a serem atualizadas). Novo processo:"
  },
  {
    id: 16,
    title: "Andar 16: Inteligência Decisória Recorrente",
    subtitle: "Ciclos contínuos de decisão melhor.",
    description: "Crie um ciclo de revisão. Como a organização continuará a aprender e a melhorar este processo? Estabeleça rituais (reuniões, relatórios) para garantir que a inteligência adquirida seja usada para tomar decisões cada vez melhores no futuro.",
    documentation: "O objetivo aqui é criar uma 'organização que aprende'. Isso é feito estabelecendo rituais e processos de revisão (como o ciclo PDCA - Plan, Do, Check, Act) para garantir que os processos e decisões sejam continuamente aprimorados com base em novos dados e experiências.",
    prompt: "Como será mantido um ciclo de melhoria contínua para esta área?",
    aiPrompt: "Proponha um 'Ciclo de Melhoria Contínua' (PDCA - Plan, Do, Check, Act) para este novo processo. Descreva brevemente o que deve acontecer em cada uma das quatro fases de forma recorrente. Processo institucionalizado:"
  },
  {
    id: 17,
    title: "Andar 17: Maestria",
    subtitle: "Antecipação, clareza e autonomia decisória.",
    description: "A maestria é alcançada quando a estrutura se torna intuitiva. A organização agora antecipa problemas, age com clareza e capacita as equipes com autonomia para tomar decisões de alta qualidade. O sistema se torna cultura.",
    documentation: "A maestria é o estado final onde o uso do MasterSolver-OS se torna parte da cultura da empresa. As equipes pensam de forma estruturada naturalmente, as decisões são de alta qualidade em todos os níveis e a organização se torna ágil e adaptativa. É a transformação de um processo em uma mentalidade.",
    prompt: "Reflita sobre o processo. Como esta jornada fortaleceu a capacidade decisória da organização?",
    aiPrompt: "Você é um líder inspirador. Escreva uma breve nota para a equipe celebrando a jornada através dos 17 andares. Destaque como a disciplina e a estrutura levaram à 'Maestria' e a uma nova cultura de tomada de decisão. Resumo da jornada:"
  }
];

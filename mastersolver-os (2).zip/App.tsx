
import React, { useState } from 'react';
import { ProjectProvider, useProject } from './contexts/ProjectContext';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import FloorContent from './components/FloorContent';
import Dashboard from './components/Dashboard';
import ReportView from './components/ReportView';
import { SettingsProvider, useSettings } from './contexts/SettingsContext';

const ProjectView: React.FC<{ setView: (view: 'app' | 'report') => void }> = ({ setView }) => {
  return (
    <div className="flex h-screen bg-[var(--bg-color)] text-[var(--text-color)] transition-colors duration-300">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header setView={setView} />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-[var(--bg-color)] p-4 sm:p-6 md:p-8">
          <FloorContent />
        </main>
      </div>
    </div>
  );
};

const AppContent: React.FC = () => {
    const { project } = useProject();
    const { theme } = useSettings();
    const [view, setView] = useState<'app' | 'report'>('app');

    React.useEffect(() => {
        const docElement = document.documentElement;
        docElement.classList.remove('light', 'dark');
        docElement.classList.add(theme);
    }, [theme]);
    
    if (view === 'report' && project) {
        return <ReportView setView={setView} />;
    }

    return project ? <ProjectView setView={setView} /> : <Dashboard />;
};

const App: React.FC = () => {
  return (
    <SettingsProvider>
      <ProjectProvider>
        <AppContent />
      </ProjectProvider>
    </SettingsProvider>
  );
};

export default App;

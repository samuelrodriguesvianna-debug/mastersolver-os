
// Represents the structure of a single floor in the 17-floor methodology
export interface Floor {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  documentation: string; // Detailed explanation of the floor's purpose
  prompt: string; // Prompt for the user input
  aiPrompt: string; // Prompt for Gemini to refine user's input
  semiAutomaticPrompt?: string; // Optional prompt for semi-automatic generation
  benchmarkPrompt?: string; // Optional prompt for benchmarking against best practices
}

// Represents the user's input for a specific floor
export interface FloorData {
  originalText: string;
  refinedText?: string;
  benchmarkText?: string;
  isCompleted: boolean;
  matrixData?: { items: { name: string; impact: number; effort: number }[] };
}

// Represents the overall state of a user's project
export interface Project {
  id: string; // A unique ID for the project
  title: string;
  entryPoint: 'diagnosis' | 'execution' | 'growth';
  currentFloor: number;
  floorData: Record<number, FloorData>; // Maps floor ID to its data
}

// Defines the shape of the project context
export interface ProjectContextType {
  project: Project | null;
  startProject: (entryPoint: 'diagnosis' | 'execution' | 'growth', title: string) => void;
  updateFloorData: (floorId: number, data: Partial<FloorData>) => void;
  goToFloor: (floorId: number) => void;
  goToNextFloor: () => void;
  resetProject: () => void;
  getPreviousFloorsData: (upToFloorId: number) => string;
}

// Defines the shape of the settings context
export type Theme = 'light' | 'dark';
export type Language = 'pt-br' | 'en';

export interface SettingsContextType {
    theme: Theme;
    setTheme: (theme: Theme) => void;
    language: Language;
    setLanguage: (language: Language) => void;
    t: (key: string) => string; // Translation function
}

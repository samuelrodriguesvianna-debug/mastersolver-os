
import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { Project, ProjectContextType, FloorData } from '../types';
import { FLOORS } from '../constants';

// Create a context for the project state.
const ProjectContext = createContext<ProjectContextType | undefined>(undefined);

// Props for the ProjectProvider component.
interface ProjectProviderProps {
  children: ReactNode;
}

// This component provides the project state to all its children.
export const ProjectProvider: React.FC<ProjectProviderProps> = ({ children }) => {
  const [project, setProject] = useState<Project | null>(null);

  // Function to start a new project.
  const startProject = useCallback((entryPoint: 'diagnosis' | 'execution' | 'growth', title: string) => {
    const initialFloorData: Record<number, FloorData> = {};
    FLOORS.forEach(floor => {
        initialFloorData[floor.id] = { originalText: '', isCompleted: false };
    });

    setProject({
      id: new Date().toISOString(), // Simple unique ID
      title,
      entryPoint,
      currentFloor: 1,
      floorData: initialFloorData,
    });
  }, []);

  // Function to update data for a specific floor.
  const updateFloorData = useCallback((floorId: number, data: Partial<FloorData>) => {
    setProject(prevProject => {
      if (!prevProject) return null;
      return {
        ...prevProject,
        floorData: {
          ...prevProject.floorData,
          [floorId]: {
            ...prevProject.floorData[floorId],
            ...data,
          },
        },
      };
    });
  }, []);

  // Function to navigate to a specific floor.
  const goToFloor = useCallback((floorId: number) => {
    setProject(prevProject => {
      if (!prevProject) return null;
      // Allow navigation only to completed floors or the current floor.
      if (floorId > prevProject.currentFloor && !prevProject.floorData[floorId-1]?.isCompleted) {
        return prevProject;
      }
      return { ...prevProject, currentFloor: floorId };
    });
  }, []);

  // Function to advance to the next floor.
  const goToNextFloor = useCallback(() => {
    setProject(prevProject => {
      if (!prevProject || prevProject.currentFloor >= FLOORS.length) return prevProject;
      
      const newProject = {
          ...prevProject,
          floorData: {
              ...prevProject.floorData,
              [prevProject.currentFloor]: {
                  ...prevProject.floorData[prevProject.currentFloor],
                  isCompleted: true,
              }
          },
          currentFloor: prevProject.currentFloor + 1,
      }
      return newProject;
    });
  }, []);
  
  // Function to reset the current project.
  const resetProject = useCallback(() => {
    setProject(null);
  }, []);

  // Helper function to get a compiled string of data from previous floors.
  const getPreviousFloorsData = useCallback((upToFloorId: number) => {
    if (!project) return "";
    let compiledData = "";
    for (let i = 1; i < upToFloorId; i++) {
        const floor = FLOORS.find(f => f.id === i);
        const data = project.floorData[i];
        if (floor && data && (data.originalText || data.refinedText)) {
            compiledData += `--- Andar ${i}: ${floor.title} ---\n`;
            compiledData += `Conteúdo: ${data.refinedText || data.originalText}\n\n`;
        }
    }
    return compiledData;
}, [project]);

  // The value provided to the context consumers.
  const value = { project, startProject, updateFloorData, goToFloor, goToNextFloor, resetProject, getPreviousFloorsData };

  return (
    <ProjectContext.Provider value={value}>
      {children}
    </ProjectContext.Provider>
  );
};

// Custom hook to easily consume the ProjectContext.
export const useProject = (): ProjectContextType => {
  const context = useContext(ProjectContext);
  if (context === undefined) {
    throw new Error('useProject must be used within a ProjectProvider');
  }
  return context;
};


import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { Theme, Language, SettingsContextType } from '../types';
import { translations } from '../translations';

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [theme, setTheme] = useState<Theme>('dark');
    const [language, setLanguage] = useState<Language>('pt-br');

    const t = useCallback((key: string): string => {
        return translations[language][key] || key;
    }, [language]);

    const value = { theme, setTheme, language, setLanguage, t };

    return (
        <SettingsContext.Provider value={value}>
            {children}
        </SettingsContext.Provider>
    );
};

export const useSettings = (): SettingsContextType => {
    const context = useContext(SettingsContext);
    if (context === undefined) {
        throw new Error('useSettings must be used within a SettingsProvider');
    }
    return context;
};

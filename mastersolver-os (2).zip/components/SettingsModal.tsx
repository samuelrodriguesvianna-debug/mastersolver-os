
import React from 'react';
import { useSettings } from '../contexts/SettingsContext';

interface SettingsModalProps {
  onClose: () => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ onClose }) => {
    const { theme, setTheme, language, setLanguage, t } = useSettings();

    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 no-print" onClick={onClose}>
            <div className="bg-[var(--card-bg-color)] border border-[var(--border-color)] rounded-lg w-full max-w-md shadow-2xl p-6" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold text-[var(--text-color)]">{t('settings')}</h2>
                    <button onClick={onClose} className="text-[var(--text-muted-color)] hover:text-[var(--text-color)] text-2xl">&times;</button>
                </div>
                
                <div className="space-y-6">
                    {/* Theme Selection */}
                    <div>
                        <label className="block text-md font-medium text-[var(--text-color)] mb-2">{t('theme')}</label>
                        <div className="flex space-x-2 rounded-md bg-[var(--bg-color)] p-1">
                            <button 
                                onClick={() => setTheme('light')}
                                className={`w-full py-2 rounded-md text-sm font-semibold transition-colors ${theme === 'light' ? 'bg-amber-500 text-white' : 'text-[var(--text-muted-color)] hover:bg-[var(--border-color)]'}`}
                            >
                                {t('light')}
                            </button>
                            <button 
                                onClick={() => setTheme('dark')}
                                className={`w-full py-2 rounded-md text-sm font-semibold transition-colors ${theme === 'dark' ? 'bg-amber-500 text-white' : 'text-[var(--text-muted-color)] hover:bg-[var(--border-color)]'}`}
                            >
                                {t('dark')}
                            </button>
                        </div>
                    </div>

                    {/* Language Selection */}
                    <div>
                        <label htmlFor="language-select" className="block text-md font-medium text-[var(--text-color)] mb-2">{t('language')}</label>
                        <select
                            id="language-select"
                            value={language}
                            onChange={e => setLanguage(e.target.value as 'pt-br' | 'en')}
                            className="w-full bg-[var(--bg-color)] border border-[var(--border-color)] rounded-md p-3 text-[var(--text-color)] focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
                        >
                            <option value="pt-br">Português (Brasil)</option>
                            <option value="en">English</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SettingsModal;

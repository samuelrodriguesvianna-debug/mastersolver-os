
import React, { useState, useEffect } from 'react';
import { useProject } from '../contexts/ProjectContext';
import { FLOORS } from '../constants';
import { refineText, generateSuggestion, generateMatrixData, getBenchmark } from '../services/geminiService';
import Loader from './Loader';
import MatrixVisualization from './MatrixVisualization';

const FloorContent: React.FC = () => {
  const { project, updateFloorData, goToNextFloor, getPreviousFloorsData } = useProject();
  const [isLoading, setIsLoading] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [text, setText] = useState('');
  const [showMatrix, setShowMatrix] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const currentFloor = project ? FLOORS.find(f => f.id === project.currentFloor) : null;
  const floorData = project && currentFloor ? project.floorData[currentFloor.id] : null;

  useEffect(() => {
    setText(floorData?.originalText || '');
    setError(null);
    setShowMatrix(false);
  }, [project?.currentFloor, floorData]);

  if (!project || !currentFloor) {
    return <div className="text-center p-8">Selecione um projeto para começar.</div>;
  }

  const handleRefine = async () => {
    if (!text.trim()) return;
    setIsLoading(true);
    setError(null);
    if (currentFloor.id === 6) {
        try {
            const result = await generateMatrixData(text);
            updateFloorData(currentFloor.id, { refinedText: result.suggestion, matrixData: { items: result.items } });
        } catch (e: any) { setError(e.message); }
    } else {
        const refined = await refineText(currentFloor.aiPrompt, text);
        if(refined.startsWith("Ocorreu um erro") || refined.startsWith("A resposta da IA foi interrompida")) setError(refined);
        else updateFloorData(currentFloor.id, { refinedText: refined });
    }
    setIsLoading(false);
  };
  
  const handleSemiAutomatic = async () => {
    if (!currentFloor.semiAutomaticPrompt || !project) return;
    setIsGenerating(true);
    setError(null);
    const prevFloorData = project.floorData[currentFloor.id - 1];
    const contextText = prevFloorData?.refinedText || prevFloorData?.originalText;
    if (!contextText) {
        setError("Não há dados suficientes no andar anterior para gerar uma sugestão.");
        setIsGenerating(false);
        return;
    }
    const suggestion = await generateSuggestion(`${currentFloor.semiAutomaticPrompt}\n\n"${contextText}"`);
    if(suggestion.startsWith("Ocorreu um erro") || suggestion.startsWith("A resposta da IA foi interrompida")) setError(suggestion);
    else updateFloorData(currentFloor.id, { refinedText: suggestion });
    setIsGenerating(false);
  };
  
  const handleBenchmark = async () => {
    if (!currentFloor.benchmarkPrompt || !text.trim()) return;
    setIsGenerating(true);
    setError(null);
    const benchmarkResult = await getBenchmark(currentFloor.benchmarkPrompt, text);
    if (benchmarkResult.startsWith("Ocorreu um erro") || benchmarkResult.startsWith("A resposta da IA foi interrompida")) setError(benchmarkResult);
    else updateFloorData(currentFloor.id, { benchmarkText: benchmarkResult });
    setIsGenerating(false);
  };

  const handleGeneratePOP = async () => {
      setIsGenerating(true);
      setError(null);
      const allPreviousData = getPreviousFloorsData(currentFloor.id);
      const popPrompt = `Você é um especialista em processos. Com base na análise a seguir, crie um rascunho de um Procedimento Operacional Padrão (POP) com: Objetivo, Responsáveis, Passo-a-passo, e Métricas de Sucesso.\n\n--- DADOS ---\n${allPreviousData}`;
      const popSuggestion = await generateSuggestion(popPrompt);
      if(popSuggestion.startsWith("Ocorreu um erro") || popSuggestion.startsWith("A resposta da IA foi interrompida")) setError(popSuggestion);
      else updateFloorData(currentFloor.id, { refinedText: popSuggestion });
      setIsGenerating(false);
  };

  const handleSaveAndContinue = () => {
    updateFloorData(currentFloor.id, { originalText: text, isCompleted: true });
    goToNextFloor();
  };

  return (
    <>
      <div className="max-w-4xl mx-auto">
        <div className="bg-[var(--card-bg-color)] rounded-lg shadow-2xl p-6 mb-6 border border-[var(--border-color)] transition-colors duration-300">
          <h2 className="font-orbitron text-2xl md:text-3xl font-bold text-amber-400 mb-2">{currentFloor.title}</h2>
          <p className="text-lg text-[var(--text-muted-color)] mb-4">{currentFloor.subtitle}</p>
          <p className="text-[var(--text-color)]">{currentFloor.description}</p>
        </div>
        
        {error && (<div className="bg-red-900/50 border border-red-500 text-red-300 p-4 rounded-md mb-6"><p className="font-bold">Erro</p><p>{error}</p></div>)}

        <div className="space-y-6">
          <div>
            <label htmlFor="floor-input" className="block text-md font-medium text-[var(--text-color)] mb-2">{currentFloor.prompt}</label>
            <textarea id="floor-input" rows={8} className="w-full bg-[var(--bg-color)] border border-[var(--border-color)] rounded-md p-3 text-[var(--text-color)] focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition" value={text} onChange={(e) => setText(e.target.value)} placeholder="Digite sua análise aqui..." />
          </div>

          {floorData?.refinedText && (
            <div className="bg-gray-800 p-4 rounded-lg border border-dashed border-amber-500/50">
              <div className="flex justify-between items-center mb-2">
                <h4 className="text-sm font-bold text-amber-400">Sugestão da IA</h4>
                {floorData.matrixData && (<button onClick={() => setShowMatrix(true)} className="px-3 py-1 text-xs font-semibold bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition">Visualizar Matriz</button>)}
              </div>
              <p className="text-gray-200 whitespace-pre-wrap">{floorData.refinedText}</p>
            </div>
          )}
          
          {floorData?.benchmarkText && (
            <div className="bg-cyan-900/30 p-4 rounded-lg border border-dashed border-cyan-500/50">
              <h4 className="text-sm font-bold text-cyan-400 mb-2">Análise de Benchmark</h4>
              <p className="text-gray-300 whitespace-pre-wrap">{floorData.benchmarkText}</p>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-[var(--border-color)] transition-colors duration-300">
            <div className="flex flex-wrap gap-4">
              <button onClick={handleRefine} disabled={isLoading || !text.trim()} className="flex items-center justify-center px-6 py-3 border border-amber-500 text-amber-500 font-semibold rounded-md hover:bg-amber-500/10 disabled:opacity-50 disabled:cursor-not-allowed transition">{isLoading ? <Loader /> : (currentFloor.id === 6 ? 'Gerar Matriz' : 'Refinar')}</button>
              {currentFloor.semiAutomaticPrompt && (<button onClick={handleSemiAutomatic} disabled={isGenerating} className="flex items-center justify-center px-6 py-3 border border-purple-500 text-purple-400 font-semibold rounded-md hover:bg-purple-500/10 disabled:opacity-50 disabled:cursor-not-allowed transition">{isGenerating ? <Loader /> : 'Sugerir'}</button>)}
              {currentFloor.benchmarkPrompt && (<button onClick={handleBenchmark} disabled={isGenerating || !text.trim()} className="flex items-center justify-center px-6 py-3 border border-cyan-500 text-cyan-400 font-semibold rounded-md hover:bg-cyan-500/10 disabled:opacity-50 disabled:cursor-not-allowed transition">{isGenerating ? <Loader /> : 'Benchmark'}</button>)}
              {currentFloor.id === 15 && (<button onClick={handleGeneratePOP} disabled={isGenerating} className="flex items-center justify-center px-6 py-3 border border-teal-500 text-teal-400 font-semibold rounded-md hover:bg-teal-500/10 disabled:opacity-50 disabled:cursor-not-allowed transition">{isGenerating ? <Loader /> : 'Gerar POP'}</button>)}
            </div>
            
            <button onClick={handleSaveAndContinue} disabled={!text.trim()} className="px-8 py-3 bg-amber-500 text-gray-900 font-bold rounded-md hover:bg-amber-600 disabled:bg-gray-600 disabled:cursor-not-allowed transition">{currentFloor.id === FLOORS.length ? 'Finalizar' : 'Salvar e Continuar'}</button>
          </div>
        </div>
      </div>
      {showMatrix && floorData?.matrixData && (<MatrixVisualization items={floorData.matrixData.items} onClose={() => setShowMatrix(false)} />)}
    </>
  );
};

export default FloorContent;


import React, { useState } from 'react';
import { useProject } from '../contexts/ProjectContext';
import Logo from './Logo';
import SettingsModal from './SettingsModal';
import { useSettings } from '../contexts/SettingsContext';

const Header: React.FC<{ setView: (view: 'app' | 'report') => void }> = ({ setView }) => {
  const { project, resetProject } = useProject();
  const { t } = useSettings();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  const handleSave = () => {
      // In a real app, this would call an API. Here we simulate it.
      setSaveStatus('saving');
      setTimeout(() => {
          setSaveStatus('saved');
          setTimeout(() => setSaveStatus('idle'), 2000);
      }, 1000);
  };

  return (
    <>
      <header className="flex-shrink-0 bg-[var(--header-bg-color)] backdrop-blur-sm border-b border-[var(--border-color)] shadow-lg no-print transition-colors duration-300">
        <div className="flex items-center justify-between p-3 sm:p-4">
          <Logo />
          <div className="flex items-center space-x-2 sm:space-x-4">
            <h1 className="hidden md:block text-lg font-semibold text-[var(--text-muted-color)] truncate">{project?.title}</h1>
            
            <button
                onClick={handleSave}
                className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                    saveStatus === 'saved'
                        ? 'bg-green-600 text-white'
                        : 'bg-transparent border border-[var(--border-color)] text-[var(--text-color)] hover:bg-[var(--border-color)]'
                }`}
                disabled={saveStatus === 'saving'}
            >
                {saveStatus === 'idle' ? t('saveProgress') : saveStatus === 'saving' ? t('saving') : t('saved')}
            </button>
            
            <button onClick={() => setView('report')} className="px-3 py-2 text-sm font-medium bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                {t('exportReport')}
            </button>
            
            <button onClick={() => setIsSettingsOpen(true)} className="p-2 rounded-md hover:bg-[var(--border-color)] text-[var(--text-muted-color)] transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106A1.532 1.532 0 0111.49 3.17zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" /></svg>
            </button>
            
            <button onClick={resetProject} className="px-3 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700 transition-colors">
                {t('endSession')}
            </button>
          </div>
        </div>
      </header>
      {isSettingsOpen && <SettingsModal onClose={() => setIsSettingsOpen(false)} />}
    </>
  );
};

export default Header;


import React, { useState } from 'react';
import { useProject } from '../contexts/ProjectContext';
import Logo from './Logo';

// --- ICONS --- //
const ClarityIcon = () => ( <svg xmlns="http://www.w.3.org/2000/svg" className="h-12 w-12 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}> <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /> </svg> );
const ExecutionIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}> <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6A2.25 2.25 0 013.75 18v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25a2.25 2.25 0 01-2.25-2.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z" /> </svg> );
const GrowthIcon = () => ( <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}> <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-3.75-.625m3.75.625l-6.25 3.75M21 18a9 9 0 11-18 0 9 9 0 0118 0z" /> </svg> );
const ConnectorIcon = ({ path, name }: { path: string, name: string }) => (
    <div className="flex flex-col items-center gap-2 text-gray-500 cursor-not-allowed" title={`${name} (Em breve)`}>
        <div className="w-16 h-16 bg-gray-800 border-2 border-dashed border-gray-600 rounded-full flex items-center justify-center">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="currentColor" viewBox="0 0 24 24"><path d={path} /></svg>
        </div>
        <span className="text-xs font-semibold">{name}</span>
    </div>
)

interface EntryCardProps { icon: React.ReactNode; title: string; description: string; onClick: () => void; }
const EntryCard: React.FC<EntryCardProps> = ({ icon, title, description, onClick }) => (
    <div onClick={onClick} className="bg-gray-800/50 border border-gray-700 rounded-lg p-6 flex flex-col items-center text-center cursor-pointer hover:bg-gray-700/50 hover:border-amber-500 transition-all duration-300 transform hover:-translate-y-1">
        {icon}
        <h3 className="font-orbitron text-xl font-bold mt-4 mb-2 text-gray-100">{title}</h3>
        <p className="text-gray-400 text-sm">{description}</p>
    </div>
);

const Dashboard: React.FC = () => {
    const { startProject } = useProject();
    const [projectName, setProjectName] = useState('');
    const [selectedEntryPoint, setSelectedEntryPoint] = useState<'diagnosis' | 'execution' | 'growth' | null>(null);

    const handleStart = () => {
        if (projectName.trim() && selectedEntryPoint) {
            startProject(selectedEntryPoint, projectName);
        } else {
            alert('Por favor, dê um nome ao seu projeto e selecione um ponto de entrada.');
        }
    };

    if (selectedEntryPoint) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-900 p-4">
                <div className="w-full max-w-md bg-gray-800 p-8 rounded-lg shadow-2xl border border-gray-700">
                    <h2 className="text-2xl font-bold text-center text-amber-400 mb-2">Nome do Projeto</h2>
                    <p className="text-center text-gray-400 mb-6">Dê um nome à sua nova análise para começar.</p>
                    <input type="text" value={projectName} onChange={(e) => setProjectName(e.target.value)} placeholder="Ex: Análise de Queda de Vendas Q3" className="w-full bg-gray-900 border border-gray-600 rounded-md p-3 text-gray-200 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition mb-6" />
                    <div className="flex space-x-4">
                        <button onClick={() => setSelectedEntryPoint(null)} className="w-full px-6 py-3 border border-gray-600 text-gray-300 font-semibold rounded-md hover:bg-gray-700 transition">Voltar</button>
                        <button onClick={handleStart} className="w-full px-6 py-3 bg-amber-500 text-gray-900 font-bold rounded-md hover:bg-amber-600 disabled:bg-gray-600 transition" disabled={!projectName.trim()}>Iniciar Análise</button>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4">
            <header className="text-center mb-10">
                <Logo className="justify-center"/>
                <p className="mt-4 text-lg text-gray-400 max-w-2xl">Um Sistema Operacional para organizar o pensamento executivo antes da ação, reduzindo erro decisório e desperdício estratégico.</p>
            </header>
            <main className="w-full max-w-5xl">
                <h2 className="text-xl font-bold text-center text-gray-300 mb-2">PAINEL DE CONTROLE DOR-DRIVEN</h2>
                <p className="text-center text-gray-500 mb-8">O usuário entra pela dor do momento, não pelo cargo. Selecione sua porta de entrada.</p>
                <div className="grid md:grid-cols-3 gap-6">
                    <EntryCard icon={<ClarityIcon />} title="Clareza & Diagnóstico" description="Entrada por confusão estratégica e dor difusa. Ideal para problemas complexos e mal definidos." onClick={() => setSelectedEntryPoint('diagnosis')} />
                    <EntryCard icon={<ExecutionIcon />} title="Execução & Sistemas" description="Entrada por falha operacional e integração. Foco em otimizar processos e sistemas existentes." onClick={() => setSelectedEntryPoint('execution')} />
                    <EntryCard icon={<GrowthIcon />} title="Crescimento & Decisão Avançada" description="Entrada por risco, escala e impacto elevado. Para decisões críticas que definem o futuro." onClick={() => setSelectedEntryPoint('growth')} />
                </div>
                
                <div className="mt-16 text-center">
                    <h3 className="text-xl font-bold text-gray-300 mb-2">CONECTORES & INTEGRAÇÕES</h3>
                    <p className="text-gray-500 mb-8">Conecte o MasterSolver a ferramentas que você já usa. (Em breve)</p>
                    <div className="flex justify-center items-center gap-8 opacity-50">
                        <ConnectorIcon name="Slack" path="M5.94,8.28h2.82V5.46H5.94V8.28Zm0,8.28h2.82V13.74H5.94v2.82Zm-2.82,0H5.94v2.82H3.12V16.56Zm0-11.1H5.94V8.28H3.12V5.46Zm8.28,5.46H8.58v2.82h2.82V11.1Zm0-5.64H8.58V8.28h2.82V5.46Zm5.64,0h-2.82V8.28h2.82V5.46Zm0,2.82h2.82V5.46H17.04V8.28Zm-5.64,8.28h2.82V13.74H11.4v2.82Zm0,2.82h2.82v2.82H11.4V19.38Zm8.28-5.64h-2.82v2.82h2.82V13.74Zm0,5.64h-2.82v2.82h2.82V19.38Z" />
                        <ConnectorIcon name="Trello" path="M18.5,3H5.5A2.5,2.5,0,0,0,3,5.5v13A2.5,2.5,0,0,0,5.5,21h13A2.5,2.5,0,0,0,21,18.5V5.5A2.5,2.5,0,0,0,18.5,3M10,16H7V7h3Zm6,0H13V7h3Z" />
                        <ConnectorIcon name="Google Drive" path="M6.2,20.4,3,15,6.2,9.6H9.4L12.6,15,9.4,20.4ZM9.7,3.6,15,12.9,12.9,16.2,7.6,6.9ZM17.8,9.6l3.2,5.4-3.2,5.4H14.6l-3.2-5.4,3.2-5.4Z" />
                    </div>
                </div>
            </main>
        </div>
    );
};

export default Dashboard;

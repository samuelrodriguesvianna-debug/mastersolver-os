
import React, { useState } from 'react';
import { FLOORS } from '../constants';
import { useProject } from '../contexts/ProjectContext';
import { useSettings } from '../contexts/SettingsContext';
import FloorDocumentationModal from './FloorDocumentationModal';
import { Floor } from '../types';

const Sidebar: React.FC = () => {
  const { project, goToFloor } = useProject();
  const { t } = useSettings();
  const [docModalFloor, setDocModalFloor] = useState<Floor | null>(null);

  if (!project) return null;

  const currentFloor = project.currentFloor;
  const { floorData } = project;

  return (
    <>
      <aside className="w-16 md:w-64 bg-[var(--sidebar-bg-color)] border-r border-[var(--border-color)] flex flex-col transition-all duration-300 no-print">
        <div className="p-4 border-b border-[var(--border-color)]">
          <h2 className="font-orbitron text-lg font-bold text-amber-400 hidden md:block">{t('elevator')}</h2>
          <h2 className="font-orbitron text-lg font-bold text-amber-400 md:hidden text-center">E</h2>
        </div>
        <nav className="flex-1 overflow-y-auto">
          <ul>
            {FLOORS.map((floor) => {
              const isCurrent = floor.id === currentFloor;
              const isCompleted = floorData[floor.id]?.isCompleted;
              const isAccessible = isCompleted || isCurrent || (floor.id > 1 && floorData[floor.id - 1]?.isCompleted);
              
              let itemClasses = 'flex items-center justify-between p-3 text-sm font-medium transition-colors duration-200 group';
              let indicatorClasses = 'w-2 h-2 rounded-full mr-3 hidden md:block flex-shrink-0';
              let textClasses = 'hidden md:inline truncate';

              if (isCurrent) {
                itemClasses += ' bg-amber-500/10 text-amber-400 border-r-4 border-amber-400';
                indicatorClasses += ' bg-amber-400';
              } else if (isCompleted) {
                itemClasses += ' text-[var(--text-color)] hover:bg-gray-700/50 cursor-pointer';
                indicatorClasses += ' bg-green-500';
              } else {
                itemClasses += ' text-gray-500 cursor-not-allowed';
                indicatorClasses += ' bg-gray-600';
              }

              return (
                <li key={floor.id}>
                  <a
                    href="#"
                    onClick={(e) => { e.preventDefault(); if (isAccessible) goToFloor(floor.id); }}
                    className={itemClasses}
                    aria-current={isCurrent ? 'page' : undefined}
                  >
                    <div className="flex items-center min-w-0">
                        <span className={indicatorClasses}></span>
                        <span className="md:hidden text-center w-full font-bold">{floor.id}</span>
                        <span className={textClasses}>{floor.id}. {floor.title.split(': ')[1]}</span>
                    </div>
                    <button onClick={(e) => { e.stopPropagation(); setDocModalFloor(floor); }} className="hidden md:block p-1 rounded-full text-gray-500 opacity-0 group-hover:opacity-100 hover:bg-gray-600/50 transition-opacity">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    </button>
                  </a>
                </li>
              );
            })}
          </ul>
        </nav>
      </aside>
      {docModalFloor && <FloorDocumentationModal floor={docModalFloor} onClose={() => setDocModalFloor(null)} />}
    </>
  );
};

export default Sidebar;


import React from 'react';
import { useProject } from '../contexts/ProjectContext';
import { useSettings } from '../contexts/SettingsContext';
import { FLOORS } from '../constants';
import Logo from './Logo';

interface ReportViewProps {
    setView: (view: 'app' | 'report') => void;
}

const ReportView: React.FC<ReportViewProps> = ({ setView }) => {
    const { project } = useProject();
    const { t } = useSettings();

    if (!project) {
        return (
            <div className="min-h-screen flex flex-col items-center justify-center p-4">
                <p>Nenhum projeto para exibir.</p>
                <button onClick={() => setView('app')} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md">Voltar</button>
            </div>
        );
    }

    return (
        <div className="bg-gray-800 min-h-screen">
            <header className="bg-gray-900 p-4 flex justify-between items-center no-print">
                <Logo />
                <div className="flex items-center space-x-4">
                    <button onClick={() => setView('app')} className="px-4 py-2 text-sm border border-gray-600 text-gray-300 rounded-md hover:bg-gray-700">
                        {t('backToEditor')}
                    </button>
                    <button onClick={() => window.print()} className="px-4 py-2 text-sm bg-amber-500 text-gray-900 font-bold rounded-md hover:bg-amber-600">
                        {t('printToPdf')}
                    </button>
                </div>
            </header>

            <main className="p-4 sm:p-8">
                <div className="max-w-4xl mx-auto bg-white text-gray-800 p-8 sm:p-12 rounded-lg shadow-2xl print-container">
                    {/* Report Header */}
                    <div className="text-center border-b-2 border-gray-200 pb-6 mb-8">
                        <h1 className="text-4xl font-orbitron font-bold text-gray-900">MASTER<span className="text-amber-600">SOLVER</span></h1>
                        <p className="text-lg text-gray-600 mt-2">{t('technicalReport')}</p>
                    </div>
                    
                    {/* Project Details */}
                    <div className="mb-10">
                        <h2 className="text-2xl font-bold border-b border-gray-300 pb-2 mb-4">Detalhes do Projeto</h2>
                        <p><strong className="w-32 inline-block">Título:</strong> {project.title}</p>
                        <p><strong className="w-32 inline-block">Ponto de Entrada:</strong> {project.entryPoint}</p>
                        <p><strong className="w-32 inline-block">Data de Geração:</strong> {new Date().toLocaleDateString()}</p>
                    </div>

                    {/* Floors Data */}
                    <div>
                        {FLOORS.filter(f => project.floorData[f.id]?.isCompleted).map((floor, index) => (
                            <div key={floor.id} className={`py-6 ${index > 0 ? 'border-t border-gray-200' : ''}`}>
                                <h3 className="text-xl font-bold text-amber-700 mb-2">{floor.title}</h3>
                                <p className="text-sm text-gray-500 italic mb-4">{floor.subtitle}</p>
                                
                                <div className="space-y-4">
                                    <div>
                                        <h4 className="font-semibold text-gray-700">Análise Original do Usuário:</h4>
                                        <p className="bg-gray-100 p-3 rounded-md mt-1 whitespace-pre-wrap">{project.floorData[floor.id].originalText}</p>
                                    </div>
                                    {project.floorData[floor.id].refinedText && (
                                        <div>
                                            <h4 className="font-semibold text-gray-700">Refinamento / Sugestão da IA:</h4>
                                            <p className="bg-blue-50 border border-blue-200 p-3 rounded-md mt-1 whitespace-pre-wrap">{project.floorData[floor.id].refinedText}</p>
                                        </div>
                                    )}
                                     {project.floorData[floor.id].benchmarkText && (
                                        <div>
                                            <h4 className="font-semibold text-gray-700">Análise de Benchmark da IA:</h4>
                                            <p className="bg-cyan-50 border border-cyan-200 p-3 rounded-md mt-1 whitespace-pre-wrap">{project.floorData[floor.id].benchmarkText}</p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </main>
        </div>
    );
};

export default ReportView;


import React from 'react';

// SVG component for the MasterSolver-OS logo, based on the provided image.
// The colors are inspired by the gold and dark theme.
const Logo: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div className={`flex items-center space-x-3 ${className}`}>
        <svg
            width="40"
            height="40"
            viewBox="0 0 56 56"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="h-8 w-8 sm:h-10 sm:w-10 text-amber-400"
        >
            <defs>
                <linearGradient id="gold-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#FDE047" />
                    <stop offset="50%" stopColor="#F59E0B" />
                    <stop offset="100%" stopColor="#D97706" />
                </linearGradient>
            </defs>
            <path
                fillRule="evenodd"
                clipRule="evenodd"
                d="M28 0C12.536 0 0 12.536 0 28C0 43.464 12.536 56 28 56C43.464 56 56 43.464 56 28C56 12.536 43.464 0 28 0ZM28 4C14.745 4 4 14.745 4 28C4 41.255 14.745 52 28 52C41.255 52 52 41.255 52 28C52 14.745 41.255 4 28 4Z"
                fill="currentColor"
                fillOpacity="0.3"
            />
            <path
                d="M14 14H18V18H14V14ZM38 14H42V18H38V14ZM14 38H18V42H14V38ZM38 38H42V42H38V38Z"
                fill="url(#gold-gradient)"
                fillOpacity="0.6"
            />
            <path
                d="M28 14L21 21L28 28L35 21L28 14Z M28 42L21 35L28 28L35 35L28 42Z M14 28L21 21V35L14 28Z M42 28L35 21V35L42 28Z"
                fill="url(#gold-gradient)"
            />
        </svg>
        <span className="font-orbitron text-xl sm:text-2xl font-bold tracking-wider text-gray-100">
            MASTER<span className="text-amber-400">SOLVER</span>
        </span>
    </div>
  );
};

export default Logo;

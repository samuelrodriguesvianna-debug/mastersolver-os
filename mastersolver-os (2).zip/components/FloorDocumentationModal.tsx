
import React from 'react';
import { Floor } from '../types';

interface FloorDocumentationModalProps {
  floor: Floor;
  onClose: () => void;
}

const FloorDocumentationModal: React.FC<FloorDocumentationModalProps> = ({ floor, onClose }) => {
    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 no-print" onClick={onClose}>
            <div 
              className="bg-[var(--card-bg-color)] border border-[var(--border-color)] rounded-lg w-full max-w-2xl shadow-2xl p-6 m-4" 
              onClick={e => e.stopPropagation()}
            >
                <div className="flex justify-between items-start mb-4">
                    <div>
                        <h2 className="font-orbitron text-xl font-bold text-amber-400">{floor.title}</h2>
                        <p className="text-[var(--text-muted-color)]">{floor.subtitle}</p>
                    </div>
                    <button onClick={onClose} className="text-[var(--text-muted-color)] hover:text-[var(--text-color)] text-3xl leading-none">&times;</button>
                </div>
                
                <div className="max-h-[60vh] overflow-y-auto pr-2">
                    <p className="text-[var(--text-color)] whitespace-pre-wrap">{floor.documentation}</p>
                </div>
            </div>
        </div>
    );
};

export default FloorDocumentationModal;

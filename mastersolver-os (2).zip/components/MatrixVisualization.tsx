
import React from 'react';

interface MatrixItem {
  name: string;
  impact: number;
  effort: number;
}

interface MatrixVisualizationProps {
  items: MatrixItem[];
  onClose: () => void;
}

const quadrantConfig = {
    q1: { title: "Vitórias Rápidas", description: "Alto Impacto, Baixo Esforço", bg: "bg-green-500/10", border: "border-green-500" },
    q2: { title: "Grandes Projetos", description: "Alto Impacto, Alto Esforço", bg: "bg-blue-500/10", border: "border-blue-500" },
    q3: { title: "Tarefas de Preenchimento", description: "Baixo Impacto, Baixo Esforço", bg: "bg-yellow-500/10", border: "border-yellow-500" },
    q4: { title: "Drenos de Tempo", description: "Baixo Impacto, Alto Esforço", bg: "bg-red-500/10", border: "border-red-500" },
};

const Quadrant: React.FC<{ title: string; description: string; items: MatrixItem[], bg: string, border: string }> = ({ title, description, items, bg, border }) => (
    <div className={`relative rounded-lg p-4 min-h-[200px] ${bg} border-2 border-dashed ${border}`}>
        <h3 className="font-bold text-gray-200">{title}</h3>
        <p className="text-xs text-gray-400 mb-3">{description}</p>
        <div className="space-y-2">
            {items.map(item => (
                <div key={item.name} className="bg-gray-800 p-2 rounded-md text-sm text-gray-300 shadow">
                    {item.name}
                </div>
            ))}
        </div>
    </div>
);

const MatrixVisualization: React.FC<MatrixVisualizationProps> = ({ items, onClose }) => {
    const quadrants: { q1: MatrixItem[], q2: MatrixItem[], q3: MatrixItem[], q4: MatrixItem[] } = { q1: [], q2: [], q3: [], q4: [] };

    items.forEach(item => {
        if (item.impact >= 6 && item.effort < 6) quadrants.q1.push(item);
        else if (item.impact >= 6 && item.effort >= 6) quadrants.q2.push(item);
        else if (item.impact < 6 && item.effort < 6) quadrants.q3.push(item);
        else quadrants.q4.push(item);
    });

    return (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-4xl shadow-2xl p-6 relative" onClick={(e) => e.stopPropagation()}>
                <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-white">&times;</button>
                <h2 className="font-orbitron text-2xl font-bold text-amber-400 mb-4 text-center">Matriz de Priorização: Impacto vs. Esforço</h2>
                <div className="grid grid-cols-2 gap-4">
                    <Quadrant items={quadrants.q1} {...quadrantConfig.q1} />
                    <Quadrant items={quadrants.q2} {...quadrantConfig.q2} />
                    <Quadrant items={quadrants.q3} {...quadrantConfig.q3} />
                    <Quadrant items={quadrants.q4} {...quadrantConfig.q4} />
                </div>
                <div className="flex justify-between items-center mt-4 px-2 text-gray-400 font-bold">
                    <span>BAIXO ESFORÇO</span>
                    <span>ALTO ESFORÇO</span>
                </div>
            </div>
        </div>
    );
};

export default MatrixVisualization;

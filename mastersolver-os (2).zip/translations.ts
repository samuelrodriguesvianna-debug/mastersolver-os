
export const translations = {
    'pt-br': {
        // Header
        saveProgress: 'Salvar Progresso',
        saving: 'Salvando...',
        saved: 'Salvo!',
        exportReport: 'Exportar Relatório',
        endSession: 'Encerrar Sessão',
        elevator: 'ELEVADOR',
        // Settings Modal
        settings: 'Configurações',
        theme: 'Tema',
        light: 'Claro',
        dark: 'Escuro',
        language: 'Idioma',
        // Report View
        backToEditor: 'Voltar para o Editor',
        printToPdf: 'Imprimir para PDF',
        technicalReport: 'Relatório Técnico de Análise Estratégica',

    },
    'en': {
        // Header
        saveProgress: 'Save Progress',
        saving: 'Saving...',
        saved: 'Saved!',
        exportReport: 'Export Report',
        endSession: 'End Session',
        elevator: 'ELEVATOR',
        // Settings Modal
        settings: 'Settings',
        theme: 'Theme',
        light: 'Light',
        dark: 'Dark',
        language: 'Language',
        // Report View
        backToEditor: 'Back to Editor',
        printToPdf: 'Print to PDF',
        technicalReport: 'Strategic Analysis Technical Report',
    }
};
